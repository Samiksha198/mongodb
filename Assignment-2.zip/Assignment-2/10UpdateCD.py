from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017")
    db = client["office"]
    coll = db["workers"]

    id = int(input('Enter Employee Id : '))
    qr = {}
    qr["_id"] = id
    for doc in coll.find(qr):
       print('Current Department : %s' % (doc['department']))
       print('Current City : %s' % (doc['city']))

       d = input('Enter New Department: ')
       c = input('Enter New City: ')

       chval = {}
       chval['city'] = c
       chval['department'] = d

       upd = {"$set": chval}

       coll.update_one(qr, upd)
       print("Employee City & Department updated...")

except:
    print("Error")