from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017")
    db = client["office"]
    coll = db["workers"]

    for doc in coll.find():
     #print(doc)
     print('%d | %s | %s | %s | %s | %d | %d | %s' % (doc['_id'], doc['name'], doc['department'], doc['post'], doc['city'], doc['_salary'], doc['_mobile'], doc['email'] ))

except:
    print('MongoDB connection failed')