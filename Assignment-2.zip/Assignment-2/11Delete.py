from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017")
    db = client["office"]
    coll = db["workers"]
    boll = db["exworkers"]

    id = int(input('Enter Employee Id : '))
    qr={}
    qr["_id"] = id

    for doc in coll.find(qr):
     boll.insert_one(doc)
    print("Document Copied to Exworkers Collection")
    coll.delete_one(qr)
    print("Document deleted...")

except:
    print("Error")