from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017")
    db = client["office"]
    coll = db["workers"]

    dic = {}
    id = int(input('Enter Employee ID : '))
    empnm = input('Enter Employee Name : ')
    dept = input('Enter Department : ')
    post = input('Enter Post : ')
    city = input('Enter City : ')
    salary = int(input('Enter Salary: '))
    mobile = int(input('Enter Mobile Number : '))
    email = input('Enter Email Address : ')

    dic["_id"] = id
    dic["name"] = empnm
    dic["department"] = dept
    dic["post"] = post
    dic["city"] = city
    dic["_salary"] = salary
    dic["_mobile"] = mobile
    dic["email"] = email

    coll.insert_one(dic)
    print('New Employee added to Workers collection')

except:
    print("Error")