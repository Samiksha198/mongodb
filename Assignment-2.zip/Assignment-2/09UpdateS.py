from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017")
    db = client["office"]
    coll = db["workers"]

    id = int(input('Enter Employee Id : '))
    qr = {}
    qr["_id"] = id
    for doc in coll.find(qr):
       print('Current Salary : %d' % (doc['_salary']))


       colmn = int(input('Enter New Salary: '))
       chval = {}
       chval['_salary'] = colmn

       upd = {"$set": chval}

       coll.update_one(qr, upd)
       print("Employee Salary updated...")

except:
    print("Error")