from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017")
    db = client["office"]
    coll = db["workers"]

    dept = input('Enter Employee Department : ')
    qr={}
    qr["department"] = dept

    for doc in coll.find(qr):
        print('%d | %s | %s | %s | %d | %d | %s' % (doc['_id'], doc['name'], doc['post'], doc['city'], doc['_salary'], doc['_mobile'],doc['email']))

except:
    print("Error")